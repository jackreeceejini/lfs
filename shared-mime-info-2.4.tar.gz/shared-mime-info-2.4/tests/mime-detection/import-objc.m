#import <stdio.h>

int main(int argc, const char *argv[])
{
  printf("Hello, world!\n");
  return 0;
}

