#include "myheader.h"

int Foo::bar()
{
    return rand() % max_;
}
