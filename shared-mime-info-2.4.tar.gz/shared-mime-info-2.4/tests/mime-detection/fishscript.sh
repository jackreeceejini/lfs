#!/usr/bin/env fish
echo Hello from fish $version
