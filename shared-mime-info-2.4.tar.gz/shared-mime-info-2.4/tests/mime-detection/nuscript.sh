#!/usr/bin/env nu
"Hello World!"