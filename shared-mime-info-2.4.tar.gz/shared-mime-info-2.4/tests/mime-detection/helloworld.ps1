#Requires -PSEdition Core

Write-Host 'Hello World!'
